package commonComponents.supportlibraries;

import org.openqa.selenium.WebDriver;

import commonComponents.com.cgi.framework.HyRoidDataTable;
import commonComponents.com.cgi.framework.selenium.HyRoidDriver;
import commonComponents.com.cgi.framework.selenium.SeleniumReport;
import commonComponents.com.cgi.framework.selenium.WebDriverUtil;

/**
 * Wrapper class for common framework objects, to be used across the entire test
 * case and dependent libraries
 * 
 * @author Cognizant
 */
public class ScriptHelper {

	private final HyRoidDataTable dataTable;
	private final SeleniumReport report;
	private HyRoidDriver craftDriver;
	private WebDriverUtil driverUtil;

	/**
	 * Constructor to initialize all the objects wrapped by the
	 * {@link ScriptHelper} class
	 * 
	 * @param dataTable
	 *            The {@link HyRoidDataTable} object
	 * @param report
	 *            The {@link SeleniumReport} object
	 * @param driver
	 *            The {@link WebDriver} object
	 * @param driverUtil
	 *            The {@link WebDriverUtil} object
	 */

	public ScriptHelper(HyRoidDataTable dataTable, SeleniumReport report,
			HyRoidDriver craftDriver, WebDriverUtil driverUtil) {
		this.dataTable = dataTable;
		this.report = report;
		this.craftDriver = craftDriver;
		this.driverUtil = driverUtil;
	}

	/**
	 * Function to get the {@link HyRoidDataTable} object
	 * 
	 * @return The {@link HyRoidDataTable} object
	 */
	public HyRoidDataTable getDataTable() {
		return dataTable;
	}

	/**
	 * Function to get the {@link SeleniumReport} object
	 * 
	 * @return The {@link SeleniumReport} object
	 */
	public SeleniumReport getReport() {
		return report;
	}

	/**
	 * Function to get the {@link CraftDriver} object
	 * 
	 * @return The {@link CraftDriver} object
	 */
	public HyRoidDriver getcraftDriver() {
		return craftDriver;
	}

	/**
	 * Function to get the {@link WebDriverUtil} object
	 * 
	 * @return The {@link WebDriverUtil} object
	 */
	public WebDriverUtil getDriverUtil() {
		return driverUtil;
	}

}