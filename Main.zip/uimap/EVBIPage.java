package uimap;

import org.openqa.selenium.By;

public class EVBIPage {
		
		public static final By headerViewEVBI=By.xpath("//table[@id='TableHeader']//h2");
		public static final By tdMemberName=By.xpath("//table[4]//tr[2]//td[2]");
		public static final By fontMessage=By.xpath("//font[@id='msg']");
		//link
		public static final By lnkMemberName = By.xpath("//table[@border=\"1\"]/tbody/tr[2]/td[1]/a");
		public static final By lnkFloatMenu = By.linkText("Float Menu");
		//text box
		public static final By txtMemberNo = By.id("MemNo");
		public static final By txtCoverageDate = By.id("CovDate");
		//drop down
		public static final By selectMainframeRegion =By.xpath("//select[@name='Region']");
		public static final By selectOBSRegion =By.xpath("//select[@name='OBS']");
		public static final By selectNavigation =By.xpath("//select[@name='ctlNavigationControl$ddlNavList']");
		//button
		public static final By btnSearch =By.xpath("//input[@name='BenefitsSearch2$btnBenefitsSearch']");
		public static final By btnLogout =By.xpath("//a[contains(@href,'logout')]");
		
}
