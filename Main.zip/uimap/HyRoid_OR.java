package uimap;
import org.openqa.selenium.By;
public class HyRoid_OR {
	
	public static final By txt_pdt_Search = By.xpath("//input[@title[contains(.,'Search for products')]]");
	public static final By lbl_pdt_Found = By.xpath("//div[@class='yQXdAl']//div[contains(.,'iPhone XS')]");
	
	
	
}


