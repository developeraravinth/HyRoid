package businesscomponents;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import commonComponents.com.cgi.framework.Status;
import com.google.common.base.Function;

import commonComponents.supportlibraries.ScriptHelper;
import uimap.HyRoid_OR;

public class HyRoid_MainFunctions extends HyRoid_CommonFunctions  {
	
	public HyRoid_MainFunctions(ScriptHelper scriptHelper) {
			super(scriptHelper);		
	}
	
	public void invokeFlipkart() {
		
		driver.manage().window().fullscreen();
		
		String flipkart_URL = dataTable.getData("General_Data", "ApplicationURL_Test");
		String flipkart_pgTitle = dataTable.getData("General_Data", "Page_Title");
		
		driver.get(flipkart_URL);
		String priWindow = driver.getWindowHandle();
		driverUtil.waitFor(3000);
		
		String secWindow = driver.getWindowHandle();
		driver.switchTo().window(secWindow);
		
		if (driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).isDisplayed()) {
			driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
		}
		
		driver.switchTo().window(priWindow);
		
		if (driver.getTitle().equals(flipkart_pgTitle)) {
			report.updateTestLog("Flipkart Landing page", "Navigated to Flipkart successful", Status.PASS);
		} else {
			report.updateTestLog("Flipkart Landing page", "Navigated to Flipkart Unsuccessful", Status.FAIL);
		}
		
		
	}
	
	
}