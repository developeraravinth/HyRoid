package businesscomponents;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

public class asd {

	public static void main(String[] args) {
		
//		String myVal = "/Users/aravinthraj/Eclipse & Java/CRAFT for CGI/HyRoid/Results/Regressionaravinth/Run_25-Dec-2018_03-39-17_PM/Screenshots/1_25-Dec-2018_03-57-09_PM_Error.png";
//		
//		String[] spli_myVal = myVal.split("/");
//		
//		//System.out.println();
//		
////		StringBuilder sb = new StringBuilder();
////		for (int i = 0; i < 10; i++) {
////			System.out.println("/" + sb.append(spli_myVal[i]) + "/");
////		}
////		
////		System.out.println(sb.toString());
//		
//		String asd = "";
//		
//		for (int i = 0; i < 10; i++) {
//			asd = asd + spli_myVal[i] + "/";
//			
//			
//			
//		}
//		
//System.out.println(asd);
	
	
		String[] hello = {"Aravinth", "Kiruthika", "Kutybaby"};
		
		ArrayList<String> fff = new ArrayList<>();
		for (String string : hello) {
			fff.add(string);
		}
		
		for (int i = 0; i < hello.length; i++) {
			hello[i] = fff.get((fff.size()-1)-i);
			System.out.println(hello[i]);
		}
		
		
		System.out.println("------------------------------------");
	
	Queue<String>asdf = new LinkedList<>();
	asdf.add("Aravinth");
	asdf.add("Kiruthika");
	asdf.add("Chellakuty");
	
	
	for (String string : asdf) {
		System.out.println("Queue Elements: " + string);
	}
	
	
	}
	
	

}
