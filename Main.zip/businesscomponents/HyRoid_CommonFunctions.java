package businesscomponents;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import commonComponents.com.cgi.framework.Status;
import commonComponents.com.cgi.framework.selenium.UtilityFunctions;
import commonComponents.supportlibraries.ScriptHelper;
import uimap.HyRoid_OR;


public class HyRoid_CommonFunctions extends UtilityFunctions {

/**
 * Constructor to initialize the component library
 * @param scriptHelper The {@link ScriptHelper} object passed from the {@link DriverScript}
 */
public HyRoid_CommonFunctions(ScriptHelper scriptHelper) {
	super(scriptHelper);
	
}

public void invokeFlipkart() {
	
	driver.manage().window().fullscreen();
	
	String flipkart_URL = dataTable.getData("General_Data", "ApplicationURL_Test");
	String flipkart_pgTitle = dataTable.getData("General_Data", "Page_Title");
	
	driver.get(flipkart_URL);
	String priWindow = driver.getWindowHandle();
	driverUtil.waitFor(3000);
	
	String secWindow = driver.getWindowHandle();
	driver.switchTo().window(secWindow);
	
	if (driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).isDisplayed()) {
		driver.findElement(By.xpath("//button[@class='_2AkmmA _29YdH8']")).click();
	}
	
	driver.switchTo().window(priWindow);
	
	if (driver.getTitle().equals(flipkart_pgTitle)) {
		report.updateTestLog("Flipkart Landing page", "Navigated to Flipkart successful", Status.PASS);
	} else {
		report.updateTestLog("Flipkart Landing page", "Navigated to Flipkart Unsuccessful", Status.FAIL);
	}
	
	
}

public void searchproduct() {
	String pdt_name = dataTable.getData("General_Data", "Search_Pdt");
	driver.findElement(HyRoid_OR.txt_pdt_Search).sendKeys(pdt_name);
	driver.findElement(HyRoid_OR.txt_pdt_Search).sendKeys(Keys.RETURN);
	
	driverUtil.waitFor(2000);
	
	//if (driver.findElement(HyRoid_OR.lbl_pdt_Found).isDisplayed()) {
		report.updateTestLog("Search for Product", "Search for product successful", Status.PASS);
	//}else {
	//	report.updateTestLog("Search for Product", "Search for product Unsuccessful", Status.FAIL);
	//}
	
	
}
	
	
}


